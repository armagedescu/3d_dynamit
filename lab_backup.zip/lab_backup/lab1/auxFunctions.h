#pragma once
#ifndef __LAB1_AUX_FUNCTIONS_H__
#define __LAB1_AUX_FUNCTIONS_H__
extern void CALLBACK auxDisplay(void);
#endif