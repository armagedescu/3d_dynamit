#pragma once
#ifndef __SEGMENT_CONE_H__
#define __SEGMENT_CONE_H__
class SegmentCone
{
public:
	SegmentCone();
};
#endif