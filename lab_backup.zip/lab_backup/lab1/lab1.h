#pragma once
#ifndef __LAB_1_H__
#define __LAB_1_H__
double getDFi();
void lab1GlDisplay();
#endif