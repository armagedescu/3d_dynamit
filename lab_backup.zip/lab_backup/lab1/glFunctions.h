#pragma once
#ifndef __LAB1_GL_FUNCTIONS_H__
#define __LAB1_GL_FUNCTIONS_H__
#include <Windows.h>
void drawCentralPoint();
void drawAxis();
void spacePrepare();
void CALLBACK resize(int width, int height);
#endif